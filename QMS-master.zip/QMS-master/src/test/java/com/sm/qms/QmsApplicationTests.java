package com.sm.qms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
