package com.sm.qms.model.constants;

public final class AppConstants {

    public static final String EMAIL_FROM = "appointment.qms@gmail.com";
    public static final String EMAIL_TO = "dileep.gdk@gmail.com";
}
