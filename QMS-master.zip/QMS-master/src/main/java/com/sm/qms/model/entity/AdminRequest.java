package com.sm.qms.model.entity;

public class AdminRequest {

    private String firstName;

    private String lastName;
    private String email;
    private String phone;
    private String password;
    private String address;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }
}
